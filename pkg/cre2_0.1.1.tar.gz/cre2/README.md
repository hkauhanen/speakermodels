# cre2 (Constant Rate Effects)

An R package to fit models of constant and variable rates of change to diachronic linguistic data.
