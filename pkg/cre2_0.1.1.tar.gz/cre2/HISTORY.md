# Version history

## 0.1.1

Bug fix: model names in the output were mis-ordered. Also, the coefficients are now consistently in the `coef` element of the returned list, not in `parameters`.

## 0.1.0

First release
